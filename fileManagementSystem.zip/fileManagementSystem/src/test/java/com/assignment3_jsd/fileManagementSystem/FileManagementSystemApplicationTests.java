package com.assignment3_jsd.fileManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
